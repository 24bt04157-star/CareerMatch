INSERT INTO users(role,name,email) VALUES
('student','Ayushi Shah','ayushi.demo@gsfcuniversity.ac.in'),
('recruiter','NovaTech Solutions','recruiter@novatech.demo')
ON CONFLICT(email) DO NOTHING;

INSERT INTO student_profiles(user_id,university,degree,semester,cgpa,city,target_career,availability,work_mode,projects,certifications,internships)
SELECT id,'GSFC University','B.Tech Computer Science & Engineering',5,8.1,'Vadodara','AI / ML Engineer','1 Dec 2026 – 31 Dec 2026','Offline',
'AI Student Chatbot — Python / AI\nIoT Drinking Water Quality Monitor — ESP32 / Sensors\nBusiness Automation Website — React / APIs',
'Python & Data Science certification\nWeb development and business automation experience','Previous project-based experience'
FROM users WHERE email='ayushi.demo@gsfcuniversity.ac.in'
ON CONFLICT(user_id) DO NOTHING;

INSERT INTO student_skills(user_id,skill,proficiency)
SELECT u.id,s.skill,s.proficiency FROM users u CROSS JOIN (VALUES
('Python',9),('SQL',5),('Machine Learning',8),('Git',7),('Java',7),('HTML/CSS',8),('JavaScript',7),('Data Structures',7),('Statistics',5),('Deep Learning',3)
) s(skill,proficiency) WHERE u.email='ayushi.demo@gsfcuniversity.ac.in'
ON CONFLICT(user_id,skill) DO UPDATE SET proficiency=EXCLUDED.proficiency;

INSERT INTO companies(user_id,name,industry,city,website,about)
SELECT id,'NovaTech Solutions','Technology & AI','Vadodara','https://example.com','NovaTech Solutions builds practical software and AI solutions for growing businesses.'
FROM users WHERE email='recruiter@novatech.demo'
ON CONFLICT DO NOTHING;

INSERT INTO internships(recruiter_id,company,role,field,city,mode,duration,start_date,stipend,education,required_skills,preferred_skills,description)
SELECT id,'NovaTech Solutions','AI / ML Intern','AI / ML','Vadodara','Offline','1 month','1 Dec 2026','₹5,000 / month','B.Tech CSE / IT',ARRAY['Python','Machine Learning','Git','SQL'],ARRAY['TensorFlow','Statistics','React'],'Work with the technology team to build and test a small machine-learning solution.'
FROM users WHERE email='recruiter@novatech.demo'
AND NOT EXISTS (SELECT 1 FROM internships WHERE role='AI / ML Intern' AND company='NovaTech Solutions');

INSERT INTO internships(recruiter_id,company,role,field,city,mode,duration,start_date,stipend,education,required_skills,preferred_skills,description)
SELECT id,'PixelCraft Labs','Frontend Developer Intern','Web Development','Vadodara','Hybrid','3 months','1 Jan 2027','₹6,000 / month','B.Tech CSE / IT',ARRAY['HTML/CSS','JavaScript','React'],ARRAY['Git','Node.js'],'Build responsive interfaces and contribute to production-style web projects.'
FROM users WHERE email='recruiter@novatech.demo'
AND NOT EXISTS (SELECT 1 FROM internships WHERE role='Frontend Developer Intern' AND company='PixelCraft Labs');

INSERT INTO internships(recruiter_id,company,role,field,city,mode,duration,start_date,stipend,education,required_skills,preferred_skills,description)
SELECT id,'DataVista','Data Analytics Intern','Data Analytics','Ahmedabad','Offline','3 months','1 Jan 2027','₹7,000 / month','B.Tech / BCA / BSc',ARRAY['Python','SQL','Statistics'],ARRAY['Power BI','Excel'],'Analyze datasets, create dashboards and communicate insights.'
FROM users WHERE email='recruiter@novatech.demo'
AND NOT EXISTS (SELECT 1 FROM internships WHERE role='Data Analytics Intern' AND company='DataVista');
