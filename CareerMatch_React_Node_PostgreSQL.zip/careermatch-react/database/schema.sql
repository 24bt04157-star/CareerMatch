CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  role VARCHAR(20) NOT NULL CHECK (role IN ('student','recruiter')),
  name VARCHAR(160) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS student_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  university VARCHAR(200), degree VARCHAR(200), semester INTEGER, cgpa NUMERIC(3,2),
  city VARCHAR(100), target_career VARCHAR(120), availability VARCHAR(200), work_mode VARCHAR(30),
  projects TEXT, certifications TEXT, internships TEXT
);
CREATE TABLE IF NOT EXISTS student_skills (
  id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  skill VARCHAR(100) NOT NULL, proficiency INTEGER NOT NULL CHECK (proficiency BETWEEN 1 AND 10),
  UNIQUE(user_id, skill)
);
CREATE TABLE IF NOT EXISTS companies (
  id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL, industry VARCHAR(160), city VARCHAR(100), website VARCHAR(255), about TEXT
);
CREATE TABLE IF NOT EXISTS internships (
  id SERIAL PRIMARY KEY, recruiter_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  company VARCHAR(200) NOT NULL, role VARCHAR(160) NOT NULL, field VARCHAR(120), city VARCHAR(100),
  mode VARCHAR(30), duration VARCHAR(60), start_date VARCHAR(100), stipend VARCHAR(100), education VARCHAR(200),
  required_skills TEXT[] DEFAULT '{}', preferred_skills TEXT[] DEFAULT '{}', description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), active BOOLEAN DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS applications (
  id SERIAL PRIMARY KEY, student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  internship_id INTEGER REFERENCES internships(id) ON DELETE CASCADE,
  status VARCHAR(40) DEFAULT 'Applied', created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, internship_id)
);
