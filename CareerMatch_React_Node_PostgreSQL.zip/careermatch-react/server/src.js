import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pg from 'pg';

dotenv.config();
const { Pool } = pg;
const app = express();
app.use(cors());
app.use(express.json());
const pool = new Pool({connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/careermatch'});

const careerSkills = {
  'AI / ML Engineer': [['Python',8],['Machine Learning',8],['SQL',6],['Statistics',6],['Deep Learning',6],['Git',6]],
  'Software Developer': [['Python',7],['Java',7],['Data Structures',8],['Git',6],['SQL',5],['JavaScript',6]],
  'Data Analyst': [['Python',6],['SQL',8],['Statistics',7],['Excel',7],['Power BI',6]],
  'Web Developer': [['HTML/CSS',8],['JavaScript',8],['React',7],['Git',6],['Node.js',6]],
  'Data Scientist': [['Python',8],['SQL',7],['Statistics',8],['Machine Learning',8],['Pandas',7]],
  'Cybersecurity Analyst': [['Networking',7],['Linux',7],['Python',6],['Cybersecurity',8],['Git',5]]
};

function scoreMatch(studentSkills, job, profile={}) {
  const map = new Map(studentSkills.map(s => [s.skill.toLowerCase(), Number(s.proficiency)]));
  const req = job.required_skills || [];
  const skillScore = req.length ? req.reduce((sum,s)=>sum + Math.min(10,map.get(s.toLowerCase()) || 0)/10,0)/req.length : 1;
  const location = profile.city && job.city && profile.city.toLowerCase()===job.city.toLowerCase() ? 1 : 0;
  const mode = profile.work_mode && job.mode && profile.work_mode.toLowerCase().includes(job.mode.toLowerCase()) ? 1 : 0.5;
  const career = profile.target_career && job.field && profile.target_career.toLowerCase().includes(job.field.toLowerCase().split(' / ')[0]) ? 1 : 0.7;
  return Math.round((skillScore*0.55 + location*0.2 + mode*0.1 + career*0.15)*100);
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'CareerMatch API'}));
app.get('/api/careers',(req,res)=>res.json(Object.entries(careerSkills).map(([name,skills])=>({name,skills}))));

app.get('/api/profile/:email',async(req,res)=>{
 try{
  const u=(await pool.query('SELECT * FROM users WHERE email=$1',[req.params.email])).rows[0];
  if(!u) return res.status(404).json({error:'User not found'});
  const p=(await pool.query('SELECT * FROM student_profiles WHERE user_id=$1',[u.id])).rows[0] || {};
  const skills=(await pool.query('SELECT skill,proficiency FROM student_skills WHERE user_id=$1 ORDER BY skill',[u.id])).rows;
  res.json({user:u,profile:p,skills});
 }catch(e){res.status(500).json({error:e.message})}
});

app.put('/api/profile/:email',async(req,res)=>{
 const c=await pool.connect();
 try{
  await c.query('BEGIN');
  const u=(await c.query('SELECT id FROM users WHERE email=$1',[req.params.email])).rows[0];
  if(!u) return res.status(404).json({error:'User not found'});
  const x=req.body;
  await c.query(`INSERT INTO student_profiles(user_id,university,degree,semester,cgpa,city,target_career,availability,work_mode,projects,certifications,internships)
   VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
   ON CONFLICT(user_id) DO UPDATE SET university=EXCLUDED.university,degree=EXCLUDED.degree,semester=EXCLUDED.semester,cgpa=EXCLUDED.cgpa,city=EXCLUDED.city,target_career=EXCLUDED.target_career,availability=EXCLUDED.availability,work_mode=EXCLUDED.work_mode,projects=EXCLUDED.projects,certifications=EXCLUDED.certifications,internships=EXCLUDED.internships`,[u.id,x.university,x.degree,x.semester,x.cgpa,x.city,x.target_career,x.availability,x.work_mode,x.projects,x.certifications,x.internships]);
  if(Array.isArray(x.skills)){
   await c.query('DELETE FROM student_skills WHERE user_id=$1',[u.id]);
   for(const s of x.skills) await c.query('INSERT INTO student_skills(user_id,skill,proficiency) VALUES($1,$2,$3)',[u.id,s.skill,Math.max(1,Math.min(10,Number(s.proficiency)||1))]);
  }
  await c.query('COMMIT'); res.json({ok:true});
 }catch(e){await c.query('ROLLBACK');res.status(500).json({error:e.message})}finally{c.release()}
});

app.get('/api/jobs',async(req,res)=>{
 try{
  const rows=(await pool.query('SELECT * FROM internships WHERE active=true ORDER BY created_at DESC')).rows;
  const email=req.query.email;
  let profile={},skills=[];
  if(email){const u=(await pool.query('SELECT id FROM users WHERE email=$1',[email])).rows[0]; if(u){profile=(await pool.query('SELECT * FROM student_profiles WHERE user_id=$1',[u.id])).rows[0]||{};skills=(await pool.query('SELECT skill,proficiency FROM student_skills WHERE user_id=$1',[u.id])).rows;}}
  res.json(rows.map(j=>({...j,match:scoreMatch(skills,j,profile),gaps:(j.required_skills||[]).filter(s=>{const x=skills.find(k=>k.skill.toLowerCase()===s.toLowerCase());return !x||Number(x.proficiency)<6;})})));
 }catch(e){res.status(500).json({error:e.message})}
});

app.post('/api/jobs',async(req,res)=>{
 try{
  const x=req.body; const u=(await pool.query('SELECT id FROM users WHERE email=$1',[x.recruiterEmail||'recruiter@novatech.demo'])).rows[0];
  const r=await pool.query(`INSERT INTO internships(recruiter_id,company,role,field,city,mode,duration,start_date,stipend,education,required_skills,preferred_skills,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,[u.id,x.company,x.role,x.field,x.city,x.mode,x.duration,x.startDate,x.stipend,x.education,x.requiredSkills||[],x.preferredSkills||[],x.description]);
  res.status(201).json(r.rows[0]);
 }catch(e){res.status(500).json({error:e.message})}
});

app.post('/api/applications',async(req,res)=>{
 try{
  const student=(await pool.query('SELECT id FROM users WHERE email=$1',[req.body.studentEmail||'ayushi.demo@gsfcuniversity.ac.in'])).rows[0];
  const r=await pool.query('INSERT INTO applications(student_id,internship_id) VALUES($1,$2) ON CONFLICT(student_id,internship_id) DO UPDATE SET status=applications.status RETURNING *',[student.id,req.body.internshipId]);
  res.status(201).json(r.rows[0]);
 }catch(e){res.status(500).json({error:e.message})}
});

app.get('/api/applications/:email',async(req,res)=>{
 try{const r=await pool.query(`SELECT a.*,i.role,i.company,i.city,i.required_skills FROM applications a JOIN users u ON u.id=a.student_id JOIN internships i ON i.id=a.internship_id WHERE u.email=$1 ORDER BY a.created_at DESC`,[req.params.email]);res.json(r.rows)}catch(e){res.status(500).json({error:e.message})}
});

app.get('/api/candidates',async(req,res)=>{
 try{
  const students=(await pool.query(`SELECT u.id,u.name,u.email,p.*,COALESCE(json_agg(json_build_object('skill',s.skill,'proficiency',s.proficiency)) FILTER (WHERE s.id IS NOT NULL),'[]') skills FROM users u JOIN student_profiles p ON p.user_id=u.id LEFT JOIN student_skills s ON s.user_id=u.id WHERE u.role='student' GROUP BY u.id,p.user_id`)).rows;
  const job=(await pool.query('SELECT * FROM internships WHERE active=true ORDER BY id LIMIT 1')).rows[0];
  res.json(students.map(s=>({...s,match:scoreMatch(s.skills.map(x=>({skill:x.skill,proficiency:x.proficiency})),job,s),gaps:(job?.required_skills||[]).filter(x=>!s.skills.some(k=>k.skill.toLowerCase()===x.toLowerCase() && Number(k.proficiency)>=6))})).sort((a,b)=>b.match-a.match));
 }catch(e){res.status(500).json({error:e.message})}
});

const port=process.env.PORT||5000;
app.listen(port,()=>console.log(`CareerMatch API running on http://localhost:${port}`));
